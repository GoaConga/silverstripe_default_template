namespace SilverStripe\Lessons;
use PageController;
class ArticlePageController extends PageController
{
    
}
